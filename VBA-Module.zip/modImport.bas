Attribute VB_Name = "modImport"
Option Explicit
' ===========================================================================
'  George-Import  (JSON-Umsatzexporte von Girokonto, Sparkonto, Kreditkarte)
'  Einstieg:  ImportDateienAuswaehlen   - Dateidialog (Mehrfachauswahl)
'             ImportOrdnerEinlesen      - alle *.json im Import-Ordner
'             ImportOrdnerOeffnen       - Ordner im Explorer oeffnen
' ===========================================================================

' ---- Blatt Buchungen
Private Const B_FIRST As Long = 6
Private Const C_DATUM As Long = 1
Private Const C_KONTO As Long = 2
Private Const C_PARTNER As Long = 3
Private Const C_REF As Long = 4
Private Const C_BETRAG As Long = 5
Private Const C_BEZ As Long = 6
Private Const C_KAT As Long = 7
Private Const C_ART As Long = 8
Private Const C_PERSON As Long = 9
Private Const C_SHARE0 As Long = 10
Private Const C_NOTIZ As Long = 18
Private Const C_INFO As Long = 19
Private Const C_KEY As Long = 20
Private Const N_DATA As Long = 20
Private Const C_F1 As Long = 21
Private Const C_F2 As Long = 31
Private Const NP As Long = 8
' ---- Blatt �bersicht (Konten)
Private Const K_FIRST As Long = 15
Private Const K_LAST As Long = 22
' ---- Blatt Fixkosten
Private Const FX_FIRST As Long = 13
Private Const FX_LAST As Long = 52
' ---- Blatt Importregeln
Private Const RG_FIRST As Long = 5
Private Const RG_LAST As Long = 204

' ---- Arbeitsdaten
Private accNum() As String, accTyp() As String, accName() As String, accTitle() As String, accFile() As String
Private accCnt() As Long, accNew() As Long, nAcc As Long
Private ownNum() As String, nOwn As Long
Private rTerm() As String, rBez() As String, rKat() As String, rArt() As String, rPers() As String
Private rShare() As Variant, nRule As Long
Private fName() As String, fKat() As String, fBetrag() As Double, fTerms() As String, fAuto() As String, nFix As Long
Private kBez() As String, kKat() As String, kTok() As String, nKnown As Long
Private pName() As String, pFold() As String, pAlias() As String, pAlle() As Boolean
Private accKey() As String
Private eBetrag() As Double
Private eName() As String, eTerms() As String, nEin As Long
Private testAntw As String
Private ausglKw As String
Private curRaw As String
Private Const E_ALIAS_ROW As Long = 16   ' Einstellungen: Zeile 17..24 = Namen in George je Person
Private tol As Double

' ===========================================================================
'  Einstiegspunkte
' ===========================================================================
Public Sub ImportDateienAuswaehlen()
    Dim f As Variant
    On Error Resume Next
    If Environ$("USERPROFILE") <> "" Then ChDrive Left$(Environ$("USERPROFILE"), 1): ChDir Environ$("USERPROFILE") & "\Downloads"
    On Error GoTo 0
    f = Application.GetOpenFilename("George-Export (*.json),*.json", , "George-Export(e) ausw�hlen � mehrere mit Strg markieren", , True)
    If Not IsArray(f) Then Exit Sub
    ImportiereDateien f, False, False
End Sub

Public Sub ImportOrdnerEinlesen()
    Dim ordner As String, fn As String
    Dim files() As String
    Dim n As Long
    ordner = ImportOrdner(True)
    If ordner = "" Then Exit Sub
    fn = Dir(ordner & PS() & "*.json")
    Do While fn <> ""
        n = n + 1
        ReDim Preserve files(1 To n)
        files(n) = ordner & PS() & fn
        fn = Dir()
    Loop
    If n = 0 Then
        MsgBox "Im Import-Ordner liegen keine JSON-Dateien." & vbLf & vbLf & ordner & vbLf & vbLf & _
               "Exportiere die Ums�tze in George als JSON und speichere/ziehe sie in diesen Ordner.", vbInformation, "George-Import"
        Exit Sub
    End If
    ImportiereDateien files, True, False
End Sub

Public Sub ImportOrdnerOeffnen()
    Dim ordner As String
    ordner = ImportOrdner(True)
    If ordner = "" Then Exit Sub
    On Error Resume Next
    ThisWorkbook.FollowHyperlink ordner
    If Err.Number <> 0 Then MsgBox "Import-Ordner: " & ordner, vbInformation, "George-Import"
End Sub

Public Sub PruefeImportOrdnerBeimOeffnen()
    Dim ordner As String, fn As String
    Dim n As Long
    On Error GoTo Ende
    ordner = ImportOrdner(False)
    If ordner = "" Then Exit Sub
    If Dir(ordner, vbDirectory) = "" Then Exit Sub
    fn = Dir(ordner & PS() & "*.json")
    Do While fn <> ""
        n = n + 1
        fn = Dir()
    Loop
    If n > 0 Then
        If MsgBox(n & " Datei(en) im Import-Ordner gefunden." & vbLf & "Jetzt importieren?", vbYesNo + vbQuestion, "George-Import") = vbYes Then
            ImportOrdnerEinlesen
        End If
    End If
Ende:
End Sub

' Ribbon (Men�band �Finanzen�)
Public Sub Ribbon_Import(control As Object)
    ImportDateienAuswaehlen
End Sub

Public Sub Ribbon_Ordner(control As Object)
    ImportOrdnerEinlesen
End Sub

Public Sub Ribbon_OrdnerOeffnen(control As Object)
    ImportOrdnerOeffnen
End Sub

' F�r automatisierte Tests: Pfade mit | getrennt, ohne Dialoge
Public Function ImportTest(ByVal pfade As String) As String
    ImportTest = ImportiereDateien(Split(pfade, "|"), False, True)
End Function

' ===========================================================================
'  Kern
' ===========================================================================
Public Function ImportiereDateien(ByVal files As Variant, ByVal verschieben As Boolean, ByVal still As Boolean) As String
    Dim wsB As Worksheet, wsO As Worksheet
    Dim txs As Collection, txF As Collection, keys As Collection, occ As Collection
    Dim root As Variant, lst As Variant, t As Variant
    Dim i As Long, j As Long, n As Long, r0 As Long, lastRow As Long, nNeu As Long, nDup As Long, nOhneKat As Long, nAkt As Long, nBew As Long
    Dim out() As Variant
    Dim fpath As String, txt As String, key As String, msg As String, aktDatei As String
    Dim tx As Object, pa As Object
    Dim val As Double, dat As Variant
    Dim art As String, bez As String, kat As String, pers As String, info As String
    Dim shares() As Variant
    Dim ai As Long
    Dim cntArt(1 To 7) As Long
    Dim arten As Variant
    Dim oldCalc As Long

    arten = Array("Ausgabe", "Fixkosten", "Einnahme", "Ausgleich", "Umbuchung", "Sparkonto", "Ignorieren")
    On Error GoTo Fehler
    Set wsB = Blatt("shBuchungen", "Buchungen")
    Set wsO = Blatt("shUebersicht", "�bersicht")

    On Error Resume Next
    Application.ScreenUpdating = False
    oldCalc = Application.Calculation
    Application.Calculation = -4135
    Application.StatusBar = "George-Import l�uft �"
    On Error GoTo Fehler

    ' ---- Dateien lesen
    Set txs = New Collection
    Set txF = New Collection
    For i = LBound(files) To UBound(files)
        fpath = CStr(files(i))
        If Len(fpath) > 0 Then
            aktDatei = fpath
            txt = LeseUtf8(fpath)
            root = Empty
            JsonParseInto txt, root
            If IsObject(root) Then
                Set lst = root
                If JIsObj(root) Then
                    Set lst = JObj(root, "transactions")
                    If lst Is Nothing Then Set lst = JObj(root, "collection")
                    If lst Is Nothing Then Set lst = New Collection
                End If
                For Each t In lst
                    If JIsObj(t) Then
                        txs.Add t
                        txF.Add DateiName(fpath)
                    End If
                Next t
            End If
        End If
    Next i
    aktDatei = ""

    ' ---- Stammdaten laden
    LadePersonen
    LadeRegeln
    LadeFixkosten
    tol = 0.25
    On Error Resume Next
    tol = CDbl(Blatt("shEinst", "Einstellungen").Range("L8").Value)
    If tol <= 0 Then tol = 0.25
    On Error GoTo Fehler
    ErkenneKonten txs, txF, wsO

    ' ---- vorhandene Buchungen: Schl�ssel + bekannte H�ndler
    Set keys = New Collection
    Set occ = New Collection
    lastRow = LetzteZeile(wsB)
    LadeBekannte wsB, lastRow, keys

    ' ---- klassifizieren
    n = txs.Count
    If n > 0 Then ReDim out(1 To n, 1 To N_DATA)
    nNeu = 0
    For i = 1 To n
        Set tx = txs(i)
        ai = AccIndex(GruppenKey(tx, CStr(txF(i))))
        key = TxKey(tx, accName(ai))
        ' gleiche Buchung mehrfach in derselben Datei (z. B. zwei gleiche Eink�ufe am selben Tag)
        If InSet(occ, key) Then
            j = CLng(occ("x" & key)) + 1
            occ.Remove "x" & key
            occ.Add j, "x" & key
            key = key & "#" & j
        Else
            occ.Add 1, "x" & key
        End If
        If InSet(keys, key) Then
            nDup = nDup + 1
            ' vorhandene Zeile: Verwendungszweck / Zahlungsreferenz aktualisieren
            r0 = CLng(keys("x" & key))
            If r0 >= B_FIRST Then
                If SStr(wsB.Cells(r0, C_REF).Value) <> TxReferenz(tx) Then
                    wsB.Cells(r0, C_REF).Value = TxtZelle(TxReferenz(tx))
                    nAkt = nAkt + 1
                End If
                If NeuBewerten(wsB, r0, TxReferenz(tx)) Then nBew = nBew + 1
            End If
        Else
            keys.Add 0, "x" & key
            val = TxBetrag(tx)
            dat = TxDatum(tx)
            ReDim shares(1 To NP)
            Klassifiziere tx, val, accTyp(ai), art, bez, kat, pers, shares, info
            nNeu = nNeu + 1
            out(nNeu, C_DATUM) = dat
            out(nNeu, C_KONTO) = TxtZelle(accName(ai))
            out(nNeu, C_PARTNER) = TxtZelle(JStr(tx, "partnerName"))
            out(nNeu, C_REF) = TxtZelle(TxReferenz(tx))
            out(nNeu, C_BETRAG) = val
            out(nNeu, C_BEZ) = TxtZelle(bez)
            out(nNeu, C_KAT) = TxtZelle(kat)
            out(nNeu, C_ART) = art
            out(nNeu, C_PERSON) = pers
            For j = 1 To NP
                out(nNeu, C_SHARE0 + j - 1) = shares(j)
            Next j
            out(nNeu, C_NOTIZ) = Empty
            out(nNeu, C_INFO) = TxtZelle(info)
            out(nNeu, C_KEY) = key
            accNew(ai) = accNew(ai) + 1
        End If
    Next i

    ' ---- unbekannte �berweiser einer Person zuordnen
    If nNeu > 0 Then ZuordnenUnbekannte out, nNeu, still
    For i = 1 To nNeu
        For j = 0 To 6
            If arten(j) = CStr(out(i, C_ART)) Then cntArt(j + 1) = cntArt(j + 1) + 1
        Next j
        If CStr(out(i, C_ART)) = "Ausgabe" And IsEmpty(out(i, C_KAT)) Then nOhneKat = nOhneKat + 1
    Next i

    ' ---- schreiben
    If nNeu > 0 Then
        r0 = lastRow + 1
        If r0 < B_FIRST Then r0 = B_FIRST
        SicherFormeln wsB, r0 + nNeu - 1
        Dim blk() As Variant
        ReDim blk(1 To nNeu, 1 To N_DATA)
        For i = 1 To nNeu
            For j = 1 To N_DATA
                blk(i, j) = out(i, j)
            Next j
        Next i
        wsB.Range(wsB.Cells(r0, 1), wsB.Cells(r0 + nNeu - 1, N_DATA)).Value = blk
        SortiereBuchungen wsB, r0 + nNeu - 1
    End If
    On Error Resume Next
    wsB.PageSetup.PrintArea = "$A$1:$W$" & Application.WorksheetFunction.Max(B_FIRST, LetzteZeile(wsB))
    On Error GoTo Fehler

    ' ---- Zusammenfassung
    msg = nNeu & " neue Buchung(en) importiert"
    If nDup > 0 Then msg = msg & ", " & nDup & " schon vorhanden (�bersprungen)"
    If nAkt > 0 Then msg = msg & ", bei " & nAkt & " davon Verwendungszweck/Zahlungsreferenz erg�nzt"
    If nBew > 0 Then msg = msg & ", " & nBew & " Personen-�berweisung(en) neu bewertet (Ausgleich/Einnahme)"
    msg = msg & "." & vbLf & vbLf
    For j = 1 To 7
        If cntArt(j) > 0 Then msg = msg & "   " & arten(j - 1) & ": " & cntArt(j) & vbLf
    Next j
    msg = msg & vbLf & "Konten:" & vbLf
    For j = 1 To nAcc
        msg = msg & "   " & accName(j) & " (" & accTyp(j) & "): " & accNew(j) & " neu von " & accCnt(j) & "  [" & accFile(j) & "]" & vbLf
    Next j
    If nOhneKat > 0 Then msg = msg & vbLf & nOhneKat & " Ausgabe(n) ohne Kategorie � im Blatt Buchungen gelb markiert."

    On Error Resume Next
    wsO.Range("B5").Value = Format(Now, "dd.mm.yyyy hh:mm") & "  �  " & nNeu & " neu, " & nDup & " Duplikate" & _
                            IIf(nOhneKat > 0, ", " & nOhneKat & " ohne Kategorie", "")
    If verschieben Then VerschiebeErledigt files
    Application.Calculation = oldCalc
    Application.ScreenUpdating = True
    Application.StatusBar = False
    On Error GoTo 0
    If Not still Then MsgBox msg, vbInformation, "George-Import"
    ImportiereDateien = Replace(msg, vbLf, " | ")
    Exit Function

Fehler:
    Dim em As String
    em = "Fehler beim Import" & IIf(aktDatei <> "", " (Datei " & DateiName(aktDatei) & ")", "") & ":" & vbLf & Err.Description
    On Error GoTo -1
    On Error Resume Next
    Application.Calculation = oldCalc
    Application.ScreenUpdating = True
    Application.StatusBar = False
    If Not still Then MsgBox em, vbExclamation, "George-Import"
    ImportiereDateien = "FEHLER: " & Replace(em, vbLf, " ")
End Function

' ===========================================================================
'  Klassifizierung
' ===========================================================================
Private Sub Klassifiziere(ByVal tx As Object, ByVal val As Double, ByVal typ As String, _
                          ByRef art As String, ByRef bez As String, ByRef kat As String, ByRef pers As String, _
                          ByRef shares() As Variant, ByRef info As String)
    Dim txt As String, ft As String, roh As String
    Dim i As Long, j As Long, k As Long, best As Long
    Dim pa As Object
    Dim partner As String
    Dim d As Double, bestD As Double

    art = "": bez = "": kat = "": pers = "": info = ""
    roh = JStr(tx, "partnerName")
    If roh = "" Then roh = TxReferenz(tx)
    txt = JStr(tx, "partnerName") & " " & JStr(tx, "reference") & " " & JStr(tx, "receiverReference") & " " & _
          JStr(tx, "merchantName") & " " & JStr(tx, "senderName") & " " & JStr(tx, "receiverName")
    ft = " " & Fold(txt) & " "
    curRaw = LCase$(txt)

    ' 0) Nullbuchungen (z. B. Abschlussbuchung)
    If val = 0 Then
        art = "Ignorieren": bez = SauberName(roh): info = "Betrag 0"
        Exit Sub
    End If

    ' 1) Spar-/Bausparkonto
    If typ = "Sparkonto" Or typ = "Bausparkonto" Then
        art = "Sparkonto"
        If InStr(ft, "zinsen") > 0 Or InStr(ft, "habenzins") > 0 Then
            bez = "Zinsen"
        ElseIf InStr(ft, " kest ") > 0 Or InStr(ft, "kapitalertrag") > 0 Then
            bez = "KESt"
        Else
            bez = SauberName(roh)
            If bez = "" Then bez = IIf(val > 0, "Einzahlung", "Auszahlung")
        End If
        info = typ
        Exit Sub
    End If

    ' 2) Importregeln
    For i = 1 To nRule
        If PasstBegriff(ft, rTerm(i)) Then
            art = rArt(i)
            If art = "" Then art = "Ausgabe"
            bez = rBez(i)
            kat = rKat(i)
            pers = rPers(i)
            For j = 1 To NP
                shares(j) = rShare(i, j)
            Next j
            If bez = "" Then
                k = BesterBekannter(ft)
                If k > 0 Then bez = kBez(k) Else bez = SauberName(roh)
            End If
            If kat = "" And art = "Ausgabe" Then
                k = BesterBekannter(ft)
                If k > 0 Then kat = kKat(k)
            End If
            info = "Regel: " & rTerm(i)
            Exit Sub
        End If
    Next i

    ' 3) Umbuchungen zwischen eigenen Konten
    Set pa = JObj(tx, "partnerAccount")
    If Not pa Is Nothing Then
        partner = NormKonto(JStr(pa, "iban"))
        If partner = "" Then partner = NormKonto(JStr(pa, "number"))
        If Len(partner) >= 4 Then
            For i = 1 To nOwn
                If GleichesKonto(partner, ownNum(i)) Then
                    art = "Umbuchung": bez = "Umbuchung " & KontoNameVon(partner): info = "eigenes Konto"
                    Exit Sub
                End If
            Next i
        End If
    End If
    If InStr(ft, " umbuchung ") > 0 Or InStr(ft, "eigenuebertrag") > 0 Or InStr(ft, "eigenueberweisung") > 0 Then
        art = "Umbuchung": bez = SauberName(roh): info = "Stichwort Umbuchung"
        Exit Sub
    End If
    If (InStr(ft, " abrechnung ") > 0 And (InStr(ft, "kreditkarte") > 0 Or InStr(ft, "mastercard") > 0 Or InStr(ft, " visa ") > 0)) _
       Or InStr(ft, "kartenabrechnung") > 0 Or InStr(ft, "kreditkartenrechnung") > 0 Or InStr(ft, "kreditkartenabrechnung") > 0 Then
        art = "Umbuchung": bez = "Kreditkartenabrechnung": info = "Einzelums�tze kommen aus dem Kreditkarten-Export"
        Exit Sub
    End If

    ' 4) Fixkosten
    If val < 0 Then
        best = 0
        bestD = 1E+99
        For i = 1 To nFix
            If fTerms(i) <> "" Then
                If PasstBegriff(ft, fTerms(i)) Then
                    If fBetrag(i) > 0 Then
                        d = Abs(Abs(val) - fBetrag(i))
                        If d <= fBetrag(i) * tol + 0.01 And d < bestD Then
                            best = i: bestD = d
                        End If
                    ElseIf best = 0 Then
                        best = i: bestD = 1E+98
                    End If
                End If
            ElseIf fBetrag(i) >= 50 And Abs(Abs(val) - fBetrag(i)) < 0.015 And best = 0 Then
                best = i: bestD = 1E+96
            ElseIf fAuto(i) <> "" Then
                If PasstEinWort(ft, fAuto(i)) Then
                    If JStr(tx, "sepaMandateId") <> "" Or (fBetrag(i) > 0 And Abs(Abs(val) - fBetrag(i)) < 0.015) Then
                        If best = 0 Then best = i: bestD = 1E+97
                    End If
                End If
            End If
        Next i
        If best > 0 Then
            art = "Fixkosten": bez = fName(best): kat = fKat(best): info = "Fixkosten"
            Exit Sub
        End If
    End If

    ' 5) Eing�nge
    If val > 0 Then
        If typ = "Kreditkarte" And BesterBekannter(ft) = 0 Then
            art = "Umbuchung": bez = "Kartenausgleich": info = "Zahlung auf die Kreditkarte"
            Exit Sub
        End If
        For i = 1 To nEin
            If eTerms(i) <> "" Then
                If PasstBegriff(ft, eTerms(i)) Then
                    art = "Einnahme": bez = eName(i): info = "Einnahme (Suchbegriff)"
                    Exit Sub
                End If
            End If
            If eBetrag(i) > 0 Then
                If Abs(val - eBetrag(i)) <= eBetrag(i) * 0.01 Then
                    art = "Einnahme": bez = eName(i): info = "Einnahme (Betrag wie " & eName(i) & ")"
                    Exit Sub
                End If
            End If
        Next i
        Dim fp As String, a As Variant
        fp = " " & Fold(JStr(tx, "partnerName")) & " "
        For i = 1 To NP
            If pName(i) <> "" And pAlias(i) <> "" Then
                For Each a In Split(pAlias(i), ";")
                    If CStr(a) <> "" Then
                        If AlleWoerter(fp, CStr(a)) Then
                            PersonBuchen i, TxReferenz(tx), "Name in George erkannt", art, pers, bez, info
                            Exit Sub
                        End If
                    End If
                Next a
            End If
        Next i
        For i = 1 To NP
            If Len(pFold(i)) >= 4 Then
                If InStr(fp, " " & pFold(i) & " ") > 0 Then
                    PersonBuchen i, TxReferenz(tx), "Name im Auftraggeber", art, pers, bez, info
                    Exit Sub
                End If
            End If
        Next i
        k = BesterBekannter(ft)
        If k > 0 Then
            art = "Ausgabe": bez = kBez(k): kat = kKat(k): info = "Gutschrift bekannter H�ndler"
            Exit Sub
        End If
        If typ = "Girokonto" And WiePerson(tx) Then
            art = "Einnahme": bez = SauberName(roh): info = "?PERSON"
            Exit Sub
        End If
        art = "Einnahme": bez = SauberName(roh): info = "Eingang"
        Exit Sub
    End If

    ' 6) bekannte H�ndler / neu
    If InStr(ft, " automat ") > 0 Or InStr(ft, " atm ") > 0 Or InStr(ft, "bargeldbehebung") > 0 Then
        roh = "Bargeldbehebung"
    End If
    k = BesterBekannter(ft)
    If k > 0 Then
        art = "Ausgabe": bez = kBez(k): kat = kKat(k): info = "bekannter H�ndler"
    Else
        art = "Ausgabe": bez = SauberName(roh): kat = "": info = "neu"
    End If
End Sub

' ===========================================================================
'  Personen aus den �berweisungen erkennen
' ===========================================================================
Public Sub SetzeTestAntworten(ByVal s As String)
    testAntw = s
End Sub

Private Function NaechsteAntwort(ByVal prompt As String, ByVal still As Boolean, ByVal vorschlag As String) As String
    Dim p As Long
    If still Then
        p = InStr(testAntw, "|")
        If p > 0 Then
            NaechsteAntwort = Left$(testAntw, p - 1)
            testAntw = Mid$(testAntw, p + 1)
        Else
            NaechsteAntwort = testAntw
            testAntw = ""
        End If
        If NaechsteAntwort = "=" Then NaechsteAntwort = vorschlag
    Else
        NaechsteAntwort = Trim$(InputBox(prompt, "George-Import � Person zuordnen", vorschlag))
    End If
End Function

Private Function OhneApo(ByVal s As String) As String
    If Left$(s, 1) = "'" Then s = Mid$(s, 2)
    OhneApo = s
End Function

Private Sub ZuordnenUnbekannte(ByRef out() As Variant, ByVal nNeu As Long, ByVal still As Boolean)
    Dim i As Long, j As Long, k As Long, nU As Long, persIdx As Long, frei As Long
    Dim uName() As String, uFold() As String, uBsp() As String
    Dim uSum() As Double
    Dim uCnt() As Long
    Dim nm As String, f As String, prompt As String, ans As String, neu As String
    Dim ws As Worksheet

    For i = 1 To nNeu
        If CStr(out(i, C_INFO)) = "?PERSON" Then
            nm = OhneApo(CStr(out(i, C_PARTNER)))
            f = Fold(nm)
            k = 0
            For j = 1 To nU
                If uFold(j) = f Then
                    k = j
                    Exit For
                End If
            Next j
            If k = 0 Then
                nU = nU + 1
                ReDim Preserve uName(1 To nU): ReDim Preserve uFold(1 To nU): ReDim Preserve uBsp(1 To nU)
                ReDim Preserve uSum(1 To nU): ReDim Preserve uCnt(1 To nU)
                uName(nU) = nm
                uFold(nU) = f
                uBsp(nU) = Format(out(i, C_DATUM), "dd.mm.yyyy") & "  " & Left$(OhneApo(CStr(out(i, C_REF))), 60)
                k = nU
            End If
            uSum(k) = uSum(k) + CDbl(out(i, C_BETRAG))
            uCnt(k) = uCnt(k) + 1
        End If
    Next i
    If nU = 0 Then Exit Sub

    Set ws = Blatt("shEinst", "Einstellungen")
    For k = 1 To nU
        frei = 0
        For j = NP To 1 Step -1
            If pName(j) = "" Then frei = j
        Next j
        prompt = "�berweisung von:  " & uName(k) & vbLf & _
                 uCnt(k) & " Zahlung(en), zusammen " & Format(uSum(k), "#,##0.00") & " �" & vbLf & _
                 "z. B. " & uBsp(k) & vbLf & vbLf & "Wer ist das?" & vbLf
        For j = 1 To NP
            If pName(j) <> "" Then prompt = prompt & "   " & j & " = " & pName(j) & vbLf
        Next j
        If frei > 0 Then prompt = prompt & "   N = als neue Person anlegen" & vbLf
        prompt = prompt & "   0 = keine Person (normale Einnahme, nicht mehr fragen)" & vbLf & _
                 "   leer / Abbrechen = sp�ter entscheiden"
        ans = UCase$(NaechsteAntwort(prompt, still, ""))
        persIdx = 0
        If ans = "N" And frei > 0 Then
            neu = SauberName(uName(k))
            If Not still Then neu = Trim$(InputBox("Name der neuen Person (so erscheint sie in der Mappe):", "Neue Person", neu))
            If neu <> "" Then
                ws.Cells(4 + frei, 1).Value = neu
                pName(frei) = neu
                pFold(frei) = Fold(neu)
                persIdx = frei
            End If
        ElseIf ans = "0" Then
            MerkeKeinePerson uName(k)
        ElseIf IsNumeric(ans) And ans <> "" Then
            j = CLng(ans)
            If j >= 1 And j <= NP Then
                If pName(j) <> "" Then persIdx = j
            End If
        End If
        If ans = "0" Then
            For i = 1 To nNeu
                If CStr(out(i, C_INFO)) = "?PERSON" Then
                    If Fold(OhneApo(CStr(out(i, C_PARTNER)))) = uFold(k) Then out(i, C_INFO) = "keine Person (Regel angelegt)"
                End If
            Next i
        End If
        If persIdx > 0 Then
            MerkeAlias persIdx, uName(k)
            For i = 1 To nNeu
                If CStr(out(i, C_INFO)) = "?PERSON" Then
                    If Fold(OhneApo(CStr(out(i, C_PARTNER)))) = uFold(k) Then
                        Dim a2 As String, p2 As String, b2 As String, i2 As String
                        PersonBuchen persIdx, OhneApo(CStr(out(i, C_REF))), "Person zugeordnet", a2, p2, b2, i2
                        out(i, C_ART) = a2
                        out(i, C_PERSON) = p2
                        out(i, C_BEZ) = TxtZelle(b2)
                        out(i, C_INFO) = TxtZelle(i2)
                    End If
                End If
            Next i
        End If
    Next k
    For i = 1 To nNeu
        If CStr(out(i, C_INFO)) = "?PERSON" Then out(i, C_INFO) = "Eingang (Person offen)"
    Next i
End Sub

Private Sub MerkeAlias(ByVal idx As Long, ByVal nm As String)
    Dim c As Range
    Dim alt As String
    Set c = Blatt("shEinst", "Einstellungen").Cells(E_ALIAS_ROW + idx, 12)
    alt = SStr(c.Value)
    If InStr(";" & Fold(alt) & ";", ";" & Fold(nm) & ";") > 0 Then Exit Sub
    If Trim$(alt) = "" Then c.Value = nm Else c.Value = alt & "; " & nm
    If pAlias(idx) = "" Then pAlias(idx) = Fold(nm) Else pAlias(idx) = pAlias(idx) & ";" & Fold(nm)
End Sub

Private Sub MerkeKeinePerson(ByVal nm As String)
    Dim ws As Worksheet
    Dim r As Long
    Set ws = Blatt("shRegeln", "Importregeln")
    For r = RG_FIRST To RG_LAST
        If Trim$(SStr(ws.Cells(r, 1).Value)) = "" Then
            ws.Cells(r, 1).Value = nm
            ws.Cells(r, 4).Value = "Einnahme"
            ws.Cells(r, 14).Value = "beim Import als �keine Person� markiert"
            Exit Sub
        End If
    Next r
End Sub

' ===========================================================================
'  Stammdaten
' ===========================================================================
Private Sub LadePersonen()
    Dim ws As Worksheet
    Dim i As Long
    Set ws = Blatt("shEinst", "Einstellungen")
    Dim a As Variant, al As String
    Dim wf As Worksheet
    Dim r As Long
    ReDim pName(1 To NP)
    ReDim pFold(1 To NP)
    ReDim pAlias(1 To NP)
    ReDim pAlle(1 To NP)
    For i = 1 To NP
        pName(i) = Trim$(SStr(ws.Cells(4 + i, 1).Value))
        pFold(i) = Fold(pName(i))
        al = ""
        pAlle(i) = (LCase$(Trim$(SStr(ws.Cells(E_ALIAS_ROW + i, 13).Value))) = "ja")
        For Each a In Split(SStr(ws.Cells(E_ALIAS_ROW + i, 12).Value), ";")
            If Fold(CStr(a)) <> "" Then al = al & ";" & Fold(CStr(a))
        Next a
        If al <> "" Then al = Mid$(al, 2)
        pAlias(i) = al
    Next i
    ausglKw = Trim$(SStr(ws.Range("L9").Value))
    ' Einnahmen mit Suchbegriff (Blatt Fixkosten, Zeilen 6-8)
    Set wf = Blatt("shFixkosten", "Fixkosten")
    nEin = 0
    ReDim eName(1 To 3)
    ReDim eTerms(1 To 3)
    ReDim eBetrag(1 To 3)
    For r = 6 To 8
        If Trim$(SStr(wf.Cells(r, 1).Value)) <> "" Then
            nEin = nEin + 1
            eName(nEin) = Trim$(SStr(wf.Cells(r, 1).Value))
            eTerms(nEin) = Trim$(SStr(wf.Cells(r, 3).Value))
            If IsNumeric(wf.Cells(r, 2).Value) And Not IsEmpty(wf.Cells(r, 2).Value) Then eBetrag(nEin) = CDbl(wf.Cells(r, 2).Value)
        End If
    Next r
End Sub

' Ist die �berweisung einer Person ein Ausgleich? (Stichwort im Verwendungszweck/Zahlungsreferenz)
Private Function IstAusgleich(ByVal refText As String) As Boolean
    If ausglKw = "*" Then
        IstAusgleich = True
    ElseIf ausglKw <> "" Then
        IstAusgleich = PasstBegriff(" " & Fold(refText) & " ", ausglKw)
    End If
End Function

Private Sub PersonBuchen(ByVal idx As Long, ByVal refText As String, ByVal wie As String, _
                         ByRef art As String, ByRef pers As String, ByRef bez As String, ByRef info As String)
    pers = pName(idx)
    If pAlle(idx) Or IstAusgleich(refText) Then
        art = "Ausgleich": bez = "Ausgleich " & pName(idx): info = wie
    Else
        art = "Einnahme": bez = "�berweisung " & pName(idx): info = wie & " � kein Ausgleich-Stichwort, bitte pr�fen"
    End If
End Sub

' Automatisch zugeordnete Personen-�berweisung beim erneuten Import neu einstufen
Private Function NeuBewerten(ByVal ws As Worksheet, ByVal r As Long, ByVal refText As String) As Boolean
    Dim info0 As String, pers0 As String, art0 As String, wie As String
    Dim a2 As String, p2 As String, b2 As String, i2 As String
    Dim i As Long, idx As Long
    info0 = SStr(ws.Cells(r, C_INFO).Value)
    pers0 = SStr(ws.Cells(r, C_PERSON).Value)
    art0 = SStr(ws.Cells(r, C_ART).Value)
    If pers0 = "" Or InStr(info0, "neu bewertet") > 0 Then Exit Function
    If art0 <> "Ausgleich" And art0 <> "Einnahme" Then Exit Function
    If Left$(info0, 22) = "Name in George erkannt" Then
        wie = "Name in George erkannt"
    ElseIf Left$(info0, 20) = "Name im Auftraggeber" Then
        wie = "Name im Auftraggeber"
    ElseIf Left$(info0, 17) = "Person zugeordnet" Then
        wie = "Person zugeordnet"
    Else
        Exit Function
    End If
    For i = 1 To NP
        If pName(i) = pers0 Then idx = i
    Next i
    If idx = 0 Then Exit Function
    PersonBuchen idx, refText, wie, a2, p2, b2, i2
    If a2 <> art0 Then
        ws.Cells(r, C_ART).Value = a2
        ws.Cells(r, C_BEZ).Value = TxtZelle(b2)
        ws.Cells(r, C_INFO).Value = TxtZelle(i2 & " (neu bewertet)")
        NeuBewerten = True
    End If
End Function

' Sieht der Auftraggeber nach einer Privatperson aus?
Private Function WiePerson(ByVal tx As Object) As Boolean
    Dim f As String, w As Variant, n As Long
    If JObj(tx, "partnerAccount") Is Nothing Then Exit Function
    f = Fold(JStr(tx, "partnerName"))
    If f = "" Then Exit Function
    For Each w In Split("kasse versicher bank gesellschaft verwaltung oesterreich finanz gemeinde magistrat kammer verband verein institut zentrum gmbh holding", " ")
        If InStr(f, CStr(w)) > 0 Then Exit Function
    Next w
    For Each w In Split(f, " ")
        n = n + 1
        If InStr(" gmbh ag kg og eu se ltd inc bv co mbh bank sparkasse raiffeisen volksbank bawag erste versicherung " & _
                 "finanzamt magistrat gemeinde stadt land republik oesterreich pensionsversicherung svs oegk ams " & _
                 "amazon paypal klarna verein holding service services gesellschaft genossenschaft stiftung ", " " & w & " ") > 0 Then Exit Function
    Next w
    WiePerson = (n >= 2 And n <= 5)
End Function

Private Sub LadeRegeln()
    Dim ws As Worksheet
    Dim r As Long, j As Long, n As Long
    Dim v As Variant
    Set ws = Blatt("shRegeln", "Importregeln")
    n = 0
    For r = RG_FIRST To RG_LAST
        If Trim$(CStr(ws.Cells(r, 1).Value)) <> "" Then n = n + 1
    Next r
    nRule = n
    If n = 0 Then Exit Sub
    ReDim rTerm(1 To n): ReDim rBez(1 To n): ReDim rKat(1 To n): ReDim rArt(1 To n): ReDim rPers(1 To n)
    ReDim rShare(1 To n, 1 To NP)
    n = 0
    For r = RG_FIRST To RG_LAST
        If Trim$(CStr(ws.Cells(r, 1).Value)) <> "" Then
            n = n + 1
            rTerm(n) = CStr(ws.Cells(r, 1).Value)
            rBez(n) = Trim$(CStr(ws.Cells(r, 2).Value))
            rKat(n) = Trim$(CStr(ws.Cells(r, 3).Value))
            rArt(n) = Trim$(CStr(ws.Cells(r, 4).Value))
            rPers(n) = Trim$(CStr(ws.Cells(r, 5).Value))
            For j = 1 To NP
                v = ws.Cells(r, 5 + j).Value
                If IsEmpty(v) Then
                    rShare(n, j) = Empty
                ElseIf LCase$(Trim$(CStr(v))) = "x" Then
                    rShare(n, j) = "x"
                ElseIf IsNumeric(v) Then
                    If CDbl(v) > 1 Then rShare(n, j) = CDbl(v) / 100 Else rShare(n, j) = CDbl(v)
                    If rShare(n, j) = 0 Then rShare(n, j) = Empty
                Else
                    rShare(n, j) = Empty
                End If
            Next j
        End If
    Next r
End Sub

Private Sub LadeFixkosten()
    Dim ws As Worksheet
    Dim r As Long, n As Long, i As Long
    Dim w As Variant
    Dim kw As String
    Set ws = Blatt("shFixkosten", "Fixkosten")
    For r = FX_FIRST To FX_LAST
        If Trim$(CStr(ws.Cells(r, 1).Value)) <> "" Then n = n + 1
    Next r
    nFix = n
    If n = 0 Then Exit Sub
    ReDim fName(1 To n): ReDim fKat(1 To n): ReDim fBetrag(1 To n): ReDim fTerms(1 To n): ReDim fAuto(1 To n)
    n = 0
    For r = FX_FIRST To FX_LAST
        If Trim$(CStr(ws.Cells(r, 1).Value)) <> "" Then
            n = n + 1
            fName(n) = Trim$(CStr(ws.Cells(r, 1).Value))
            fKat(n) = Trim$(CStr(ws.Cells(r, 2).Value))
            If IsNumeric(ws.Cells(r, 3).Value) And Not IsEmpty(ws.Cells(r, 3).Value) Then fBetrag(n) = CDbl(ws.Cells(r, 3).Value)
            fTerms(n) = Trim$(CStr(ws.Cells(r, 7).Value))
            kw = ""
            For Each w In Split(Fold(fName(n)), " ")
                If Len(w) >= 4 And InStr(" versicherung beitrag kostenbeitrag personen wohnung bereitstellung monatlich abo gebuehr konto ", " " & w & " ") = 0 Then
                    kw = kw & ";" & w
                End If
            Next w
            If kw <> "" Then kw = Mid$(kw, 2)
            fAuto(n) = kw
        End If
    Next r
End Sub

Private Sub LadeBekannte(ByVal ws As Worksheet, ByVal lastRow As Long, ByRef keys As Collection)
    Dim r As Long, n As Long, i As Long, hit As Long
    Dim data As Variant
    Dim b As String, k As String
    nKnown = 0
    If lastRow < B_FIRST Then Exit Sub
    data = ws.Range(ws.Cells(B_FIRST, 1), ws.Cells(lastRow, N_DATA)).Value
    ReDim kBez(1 To lastRow): ReDim kKat(1 To lastRow): ReDim kTok(1 To lastRow)
    For r = 1 To UBound(data, 1)
        k = SStr(data(r, C_KEY))
        If k <> "" Then
            If Not InSet(keys, k) Then keys.Add B_FIRST + r - 1, "x" & k
        End If
        If SStr(data(r, C_ART)) = "Ausgabe" And SStr(data(r, C_BEZ)) <> "" And SStr(data(r, C_KAT)) <> "" Then
            b = SStr(data(r, C_BEZ))
            hit = 0
            For i = 1 To nKnown
                If kBez(i) = b Then hit = i: Exit For
            Next i
            If hit = 0 Then
                nKnown = nKnown + 1
                hit = nKnown
                kBez(hit) = b
                kTok(hit) = Fold(b)
            End If
            kKat(hit) = SStr(data(r, C_KAT))
        End If
    Next r
End Sub

' ===========================================================================
'  Konten erkennen
' ===========================================================================
Private Function GruppenKey(ByVal tx As Object, ByVal fname As String) As String
    Dim num As String
    num = NormKonto(JStr(tx, "ownerAccountNumber"))
    If Len(num) >= 4 Then
        GruppenKey = "N:" & num
    Else
        GruppenKey = "F:" & LCase$(fname) & "|" & LCase$(JStr(tx, "ownerAccountTitle"))
    End If
End Function

Private Sub ErkenneKonten(ByVal txs As Collection, ByVal txF As Collection, ByVal wsO As Worksheet)
    Dim i As Long, r As Long, a As Long
    Dim num As String, ib As String, typ As String, gk As String, title As String, fname As String
    Dim tx As Object
    Dim accPN() As Long
    Dim accRaw() As String
    nAcc = 0
    ReDim accNum(1 To 1): ReDim accTyp(1 To 1): ReDim accName(1 To 1): ReDim accTitle(1 To 1)
    ReDim accFile(1 To 1): ReDim accCnt(1 To 1): ReDim accNew(1 To 1): ReDim accKey(1 To 1)
    ReDim accPN(1 To 1): ReDim accRaw(1 To 1)
    ' 1. Durchlauf: Gruppen bilden (je Kontonummer, sonst je Datei)
    For i = 1 To txs.Count
        Set tx = txs(i)
        fname = CStr(txF(i))
        gk = GruppenKey(tx, fname)
        a = AccIndex(gk)
        If a = 0 Then
            nAcc = nAcc + 1
            ReDim Preserve accNum(1 To nAcc): ReDim Preserve accTyp(1 To nAcc): ReDim Preserve accName(1 To nAcc)
            ReDim Preserve accTitle(1 To nAcc): ReDim Preserve accFile(1 To nAcc): ReDim Preserve accCnt(1 To nAcc)
            ReDim Preserve accNew(1 To nAcc): ReDim Preserve accKey(1 To nAcc)
            ReDim Preserve accPN(1 To nAcc): ReDim Preserve accRaw(1 To nAcc)
            a = nAcc
            accKey(a) = gk
            accNum(a) = NormKonto(JStr(tx, "ownerAccountNumber"))
            accRaw(a) = JStr(tx, "ownerAccountNumber")
            accTitle(a) = JStr(tx, "ownerAccountTitle")
            accFile(a) = fname
        End If
        accCnt(a) = accCnt(a) + 1
        If Trim$(JStr(tx, "partnerName")) <> "" Then accPN(a) = accPN(a) + 1
    Next i
    ' 2. Durchlauf: Konto zuordnen
    For a = 1 To nAcc
        num = accNum(a)
        title = accTitle(a)
        ' a) Kontonummer steht in der �bersicht
        If Len(num) >= 4 Then
            For r = K_FIRST To K_LAST
                ib = NormKonto(SStr(wsO.Cells(r, 4).Value))
                If SStr(wsO.Cells(r, 1).Value) <> "" And GleichesKonto(num, ib) Then
                    accName(a) = SStr(wsO.Cells(r, 1).Value)
                    accTyp(a) = SStr(wsO.Cells(r, 2).Value)
                    Exit For
                End If
            Next r
        End If
        ' b) Kontobezeichnung = Kontoname in der �bersicht
        If accName(a) = "" And title <> "" Then
            For r = K_FIRST To K_LAST
                If SStr(wsO.Cells(r, 1).Value) <> "" And LCase$(SStr(wsO.Cells(r, 1).Value)) = LCase$(title) Then
                    accName(a) = SStr(wsO.Cells(r, 1).Value)
                    accTyp(a) = SStr(wsO.Cells(r, 2).Value)
                    Exit For
                End If
            Next r
        End If
        ' c) Typ aus Kontobezeichnung, Dateiname oder Buchungsbild (Kreditkarte: nie ein Empf�ngername)
        If accName(a) = "" Then
            typ = RateTyp(title)
            If typ = "" Then typ = RateTyp(accFile(a))
            If typ = "" Then
                If accPN(a) = 0 Then typ = "Kreditkarte" Else typ = "Girokonto"
            End If
            accTyp(a) = typ
            accName(a) = typ
            For r = K_FIRST To K_LAST
                If SStr(wsO.Cells(r, 2).Value) = typ And SStr(wsO.Cells(r, 1).Value) <> "" Then
                    accName(a) = SStr(wsO.Cells(r, 1).Value)
                    If Len(num) >= 4 And Trim$(SStr(wsO.Cells(r, 4).Value)) = "" Then wsO.Cells(r, 4).Value = "'" & accRaw(a)
                    Exit For
                End If
            Next r
        End If
        If accTyp(a) = "" Then accTyp(a) = "Girokonto"
    Next a
    ' eigene Kontonummern
    nOwn = 0
    ReDim ownNum(1 To nAcc + (K_LAST - K_FIRST + 1) + 1)
    For i = 1 To nAcc
        If Len(accNum(i)) >= 4 Then nOwn = nOwn + 1: ownNum(nOwn) = accNum(i)
    Next i
    For r = K_FIRST To K_LAST
        ib = NormKonto(SStr(wsO.Cells(r, 4).Value))
        If Len(ib) >= 4 Then nOwn = nOwn + 1: ownNum(nOwn) = ib
    Next r
End Sub

Private Function AccIndex(ByVal gk As String) As Long
    Dim i As Long
    For i = 1 To nAcc
        If accKey(i) = gk Then AccIndex = i: Exit Function
    Next i
End Function

Private Function KontoNameVon(ByVal num As String) As String
    Dim i As Long, r As Long
    Dim wsO As Worksheet
    For i = 1 To nAcc
        If GleichesKonto(num, accNum(i)) Then KontoNameVon = accName(i): Exit Function
    Next i
    Set wsO = Blatt("shUebersicht", "�bersicht")
    For r = K_FIRST To K_LAST
        If GleichesKonto(num, NormKonto(CStr(wsO.Cells(r, 4).Value))) Then KontoNameVon = CStr(wsO.Cells(r, 1).Value): Exit Function
    Next r
    KontoNameVon = "eigenes Konto"
End Function

Private Function RateTyp(ByVal s As String) As String
    Dim t As String
    t = " " & Fold(s) & " "
    t = Replace(t, "sparkasse", " ")
    If Trim$(t) = "" Then Exit Function
    If InStr(t, "kredit") > 0 Or InStr(t, "card") > 0 Or InStr(t, "visa") > 0 Or InStr(t, "master") > 0 Or InStr(t, "karte") > 0 Then
        RateTyp = "Kreditkarte"
    ElseIf InStr(t, "bauspar") > 0 Then
        RateTyp = "Bausparkonto"
    ElseIf InStr(t, "spar") > 0 Or InStr(t, "kapital") > 0 Then
        RateTyp = "Sparkonto"
    ElseIf InStr(t, "giro") > 0 Or InStr(t, "konto") > 0 Or InStr(t, "gehalt") > 0 Then
        RateTyp = "Girokonto"
    End If
End Function

' ===========================================================================
'  Schreiben / Sortieren
' ===========================================================================
Private Function GenutzteBis(ByVal ws As Worksheet) As Long
    With ws.UsedRange
        GenutzteBis = .Row + .Rows.Count - 1
    End With
End Function

Private Function LetzteZeile(ByVal ws As Worksheet) As Long
    Dim bis As Long, r As Long
    Dim a As Variant, k As Variant
    LetzteZeile = B_FIRST - 1
    bis = GenutzteBis(ws)
    If bis < B_FIRST Then Exit Function
    a = ws.Range(ws.Cells(B_FIRST, C_DATUM), ws.Cells(bis + 1, C_DATUM)).Value
    k = ws.Range(ws.Cells(B_FIRST, C_KEY), ws.Cells(bis + 1, C_KEY)).Value
    For r = UBound(a, 1) To 1 Step -1
        If SStr(a(r, 1)) <> "" Or SStr(k(r, 1)) <> "" Then
            LetzteZeile = B_FIRST + r - 1
            Exit Function
        End If
    Next r
End Function

Private Sub SicherFormeln(ByVal ws As Worksheet, ByVal bisZeile As Long)
    Dim r As Long
    r = GenutzteBis(ws)
    Do While r > B_FIRST
        If ws.Cells(r, C_F1).HasFormula Then Exit Do
        r = r - 1
    Loop
    If r >= bisZeile Then Exit Sub
    ws.Range(ws.Cells(B_FIRST, 1), ws.Cells(B_FIRST, C_F2)).Copy
    ws.Range(ws.Cells(r + 1, 1), ws.Cells(bisZeile, C_F2)).PasteSpecial -4122    ' Formate
    ws.Range(ws.Cells(B_FIRST, C_F1), ws.Cells(B_FIRST, C_F2)).Copy ws.Range(ws.Cells(r + 1, C_F1), ws.Cells(bisZeile, C_F2))
    Application.CutCopyMode = False
End Sub

Private Sub SortiereBuchungen(ByVal ws As Worksheet, ByVal bisZeile As Long)
    Dim rng As Range
    On Error Resume Next
    If ws.FilterMode Then ws.ShowAllData
    Set rng = ws.Range(ws.Cells(B_FIRST, 1), ws.Cells(bisZeile, N_DATA))
    rng.Sort Key1:=ws.Cells(B_FIRST, C_DATUM), Order1:=1, Key2:=ws.Cells(B_FIRST, C_KONTO), Order2:=1, Header:=2
    On Error GoTo 0
End Sub

Private Sub VerschiebeErledigt(ByVal files As Variant)
    Dim ordner As String, ziel As String, fn As String
    Dim i As Long
    On Error Resume Next
    ordner = ImportOrdner(True)
    If ordner = "" Then Exit Sub
    ordner = ordner & PS() & "erledigt"
    If Dir(ordner, vbDirectory) = "" Then MkDir ordner
    For i = LBound(files) To UBound(files)
        fn = DateiName(CStr(files(i)))
        ziel = ordner & PS() & fn
        If Dir(ziel) <> "" Then ziel = ordner & PS() & Format(Now, "yyyymmdd-hhmmss") & "_" & fn
        Name CStr(files(i)) As ziel
    Next i
End Sub

' ===========================================================================
'  Hilfsfunktionen
' ===========================================================================
Public Function Blatt(ByVal code As String, ByVal nm As String) As Worksheet
    Dim ws As Worksheet
    On Error Resume Next
    For Each ws In ThisWorkbook.Worksheets
        If ws.CodeName = code Then
            Set Blatt = ws
            Exit Function
        End If
    Next ws
    Set Blatt = ThisWorkbook.Worksheets(nm)
End Function

Private Function PS() As String
    PS = Application.PathSeparator
End Function

Private Function ImportOrdner(ByVal anlegen As Boolean) As String
    Dim p As String, basis As String
    On Error Resume Next
    p = Trim$(CStr(Blatt("shEinst", "Einstellungen").Range("L5").Value))
    If p = "" Then
        basis = MappenOrdner()
        If basis = "" And anlegen Then basis = OrdnerWaehlen()
        If basis = "" Then
            ImportOrdner = ""
            Exit Function
        End If
        p = basis & PS() & "Import"
    End If
    If Right$(p, 1) = PS() Then p = Left$(p, Len(p) - 1)
    If anlegen Then
        If Dir(p, vbDirectory) = "" Then MkDir p
        If Dir(p & PS() & "erledigt", vbDirectory) = "" Then MkDir p & PS() & "erledigt"
    End If
    ImportOrdner = p
End Function

Public Function ImportOrdnerPfad() As String
    ImportOrdnerPfad = ImportOrdner(True)
End Function

' Lokaler Ordner der Mappe � auch wenn sie in OneDrive/SharePoint liegt (ThisWorkbook.Path ist dann eine URL)
Private Function MappenOrdner() As String
    Dim p As String
    p = ThisWorkbook.Path
    If p = "" Then Exit Function
    If LCase$(Left$(p, 4)) <> "http" Then
        MappenOrdner = p
        Exit Function
    End If
    MappenOrdner = OneDriveLokal(p)
End Function

Public Function OneDriveLokal(ByVal url As String) As String
    Dim teile() As String, roots As Variant, root As Variant
    Dim i As Long, j As Long
    Dim rest As String, kandidat As String
    url = UrlDecode(url)
    url = Replace(url, "\", "/")
    ' https://host/a/b/c  -> Segmente ab dem Host
    teile = Split(Mid$(url, InStr(url, "//") + 2), "/")
    roots = Array(Environ$("OneDriveCommercial"), Environ$("OneDriveConsumer"), Environ$("OneDrive"))
    On Error Resume Next
    For Each root In roots
        If CStr(root) <> "" Then
            ' Mappe direkt im OneDrive-Stamm?
            For i = 1 To UBound(teile)
                rest = ""
                For j = i To UBound(teile)
                    rest = rest & PS() & teile(j)
                Next j
                kandidat = CStr(root) & rest
                If Dir(kandidat & PS() & ThisWorkbook.Name) <> "" Then
                    OneDriveLokal = kandidat
                    Exit Function
                End If
            Next i
            If Dir(CStr(root) & PS() & ThisWorkbook.Name) <> "" Then
                OneDriveLokal = CStr(root)
                Exit Function
            End If
        End If
    Next root
End Function

Private Function UrlDecode(ByVal s As String) As String
    Dim i As Long
    Dim out As String, h As String
    i = 1
    Do While i <= Len(s)
        If Mid$(s, i, 1) = "%" And i + 2 <= Len(s) Then
            h = Mid$(s, i + 1, 2)
            out = out & Chr$(CLng("&H" & h))
            i = i + 3
        Else
            out = out & Mid$(s, i, 1)
            i = i + 1
        End If
    Loop
    ' UTF-8-Bytes (z. B. %C3%BC) zusammensetzen
    out = Replace(out, Chr$(195) & Chr$(164), ChrW(228))
    out = Replace(out, Chr$(195) & Chr$(182), ChrW(246))
    out = Replace(out, Chr$(195) & Chr$(188), ChrW(252))
    out = Replace(out, Chr$(195) & Chr$(132), ChrW(196))
    out = Replace(out, Chr$(195) & Chr$(150), ChrW(214))
    out = Replace(out, Chr$(195) & Chr$(156), ChrW(220))
    out = Replace(out, Chr$(195) & Chr$(159), ChrW(223))
    UrlDecode = out
End Function

' Fallback: Ordner einmal ausw�hlen lassen und in Einstellungen!L5 merken
Private Function OrdnerWaehlen() As String
    Dim fd As Object
    Dim p As String
    On Error Resume Next
    MsgBox "Der Speicherort der Mappe konnte nicht ermittelt werden." & vbLf & _
           "Bitte w�hle den Ordner, in dem die Mappe liegt � dort wird der Ordner �Import� angelegt.", vbInformation, "George-Import"
    Set fd = Application.FileDialog(4)
    fd.Title = "Ordner der Mappe ausw�hlen"
    If fd.Show = -1 Then p = fd.SelectedItems(1)
    If p <> "" Then
        Blatt("shEinst", "Einstellungen").Range("L5").Value = p & PS() & "Import"
        OrdnerWaehlen = p
    End If
End Function

Private Function DateiName(ByVal p As String) As String
    Dim i As Long
    i = InStrRev(p, "\")
    If InStrRev(p, "/") > i Then i = InStrRev(p, "/")
    If InStrRev(p, ":") > i And Application.PathSeparator = ":" Then i = InStrRev(p, ":")
    DateiName = Mid$(p, i + 1)
End Function

Private Function SStr(ByVal v As Variant) As String
    If IsError(v) Or IsNull(v) Or IsEmpty(v) Then
        SStr = ""
    Else
        SStr = CStr(v)
    End If
End Function

' Text so schreiben, dass Excel ihn nicht als Formel, Zahl oder Datum deutet
Private Function TxtZelle(ByVal s As String) As Variant
    If s = "" Then
        TxtZelle = Empty
    ElseIf InStr("=+-@'", Left$(s, 1)) > 0 Or IsNumeric(s) Or IsDate(s) Then
        TxtZelle = "'" & s
    Else
        TxtZelle = s
    End If
End Function

Private Function InSet(ByVal c As Collection, ByVal k As String) As Boolean
    Dim v As Variant
    On Error Resume Next
    v = c("x" & k)
    InSet = (Err.Number = 0)
    Err.Clear
End Function

Public Function Fold(ByVal s As String) As String
    Dim i As Long, code As Long
    Dim out As String, ch As String
    s = LCase$(s)
    s = Replace(s, ChrW(228), "ae")
    s = Replace(s, ChrW(246), "oe")
    s = Replace(s, ChrW(252), "ue")
    s = Replace(s, ChrW(223), "ss")
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        code = AscW(ch)
        If code < 0 Then code = code + 65536
        If (code >= 97 And code <= 122) Or (code >= 48 And code <= 57) Then
            out = out & ch
        ElseIf code = 39 Or code = 8217 Then
            ' Apostroph weglassen
        ElseIf code >= 224 And code <= 255 Then
            out = out & Mid$("aaaaaaaceeeeiiiidnooooo/ouuuuyty", code - 223, 1)
        Else
            out = out & " "
        End If
    Next i
    Do While InStr(out, "  ") > 0
        out = Replace(out, "  ", " ")
    Loop
    Fold = Trim$(out)
End Function

' Begriff passt, wenn eine der ;-Alternativen als Teilstring (ab 4 Zeichen) oder mit allen W�rtern vorkommt
Private Function PasstBegriff(ByVal ft As String, ByVal begriffe As String) As Boolean
    Dim alt As Variant
    Dim a As String
    For Each alt In Split(begriffe, ";")
        a = Fold(CStr(alt))
        If a <> "" And NurEinzelzeichen(a) Then
            ' z. B. "H&M": nur als exakter Text, sonst trifft "Ges.m.b.H."
            If InStr(curRaw, LCase$(Trim$(CStr(alt)))) > 0 Then
                PasstBegriff = True
                Exit Function
            End If
        ElseIf a <> "" Then
            If Len(a) >= 4 And InStr(ft, a) > 0 Then
                PasstBegriff = True
                Exit Function
            End If
            If AlleWoerter(ft, a) Then
                PasstBegriff = True
                Exit Function
            End If
        End If
    Next alt
End Function

Private Function NurEinzelzeichen(ByVal folded As String) As Boolean
    Dim w As Variant
    NurEinzelzeichen = True
    For Each w In Split(folded, " ")
        If Len(w) > 1 Then
            NurEinzelzeichen = False
            Exit Function
        End If
    Next w
End Function

Private Function PasstEinWort(ByVal ft As String, ByVal woerter As String) As Boolean
    Dim w As Variant
    For Each w In Split(woerter, ";")
        If w <> "" Then
            If InStr(ft, " " & w & " ") > 0 Or (Len(w) >= 6 And InStr(ft, w) > 0) Then
                PasstEinWort = True
                Exit Function
            End If
        End If
    Next w
End Function

Private Function AlleWoerter(ByVal ft As String, ByVal folded As String) As Boolean
    Dim w As Variant
    AlleWoerter = True
    For Each w In Split(folded, " ")
        If w <> "" Then
            If InStr(ft, " " & w & " ") = 0 Then
                AlleWoerter = False
                Exit Function
            End If
        End If
    Next w
End Function

Private Function BesterBekannter(ByVal ft As String) As Long
    Dim i As Long, sc As Long, best As Long
    For i = 1 To nKnown
        If kTok(i) <> "" Then
            If AlleWoerter(ft, kTok(i)) Then
                sc = (UBound(Split(kTok(i), " ")) + 1) * 1000 + Len(kTok(i))
                If sc > best Then
                    best = sc
                    BesterBekannter = i
                End If
            End If
        End If
    Next i
End Function

Private Function NormKonto(ByVal s As String) As String
    Dim i As Long
    Dim ch As String, out As String
    s = UCase$(s)
    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If (ch >= "A" And ch <= "Z") Or (ch >= "0" And ch <= "9") Then out = out & ch
    Next i
    NormKonto = out
End Function

Private Function GleichesKonto(ByVal a As String, ByVal b As String) As Boolean
    If Len(a) < 4 Or Len(b) < 4 Then Exit Function
    GleichesKonto = (Right$(a, Len(b)) = b) Or (Right$(b, Len(a)) = a)
End Function

Private Function TxBetrag(ByVal tx As Object) As Double
    Dim a As Object
    Dim p As Long
    Set a = JObj(tx, "amount")
    If a Is Nothing Then Exit Function
    p = CLng(JNum(a, "precision"))
    TxBetrag = Round(JNum(a, "value") / (10 ^ p), 2)
End Function

Private Function TxDatum(ByVal tx As Object) As Variant
    Dim s As String
    s = JStr(tx, "booking")
    If s = "" Then s = JStr(tx, "valuation")
    If s Like "####-##-##*" Then
        TxDatum = DateSerial(CInt(Left$(s, 4)), CInt(Mid$(s, 6, 2)), CInt(Mid$(s, 9, 2)))
    ElseIf s Like "##.##.####*" Then
        TxDatum = DateSerial(CInt(Mid$(s, 7, 4)), CInt(Mid$(s, 4, 2)), CInt(Left$(s, 2)))
    Else
        TxDatum = Empty
    End If
End Function

Private Function TxReferenz(ByVal tx As Object) As String
    Dim s As String
    Dim z As String
    s = Trim$(JStr(tx, "reference"))
    z = Trim$(JStr(tx, "receiverReference"))
    If z <> "" And InStr(1, s, z, vbTextCompare) = 0 Then
        If s = "" Then s = z Else s = s & "  �  " & z
    End If
    TxReferenz = s
End Function

Private Function TxKey(ByVal tx As Object, ByVal konto As String) As String
    Dim a As Object
    Dim s As String
    Set a = JObj(tx, "amount")
    s = LCase$(konto) & "|" & Left$(JStr(tx, "booking"), 10) & "|"
    If Not a Is Nothing Then s = s & JStr(a, "value")
    s = s & "|" & Left$(Fold(JStr(tx, "partnerName") & " " & JStr(tx, "reference")), 80)
    If JStr(tx, "referenceNumber") <> "" Then s = s & "|" & JStr(tx, "referenceNumber")
    TxKey = s
End Function

' Macht aus 'POS 12,40 0001 K1 02.09. 10:15 O TRAFIK SCHOENHERR' etwas Lesbares
Public Function SauberName(ByVal roh As String) As String
    Dim w As Variant
    Dim s As String, u As String, out As String
    Dim i As Long, digits As Long
    roh = Replace(Replace(roh, vbLf, " "), vbCr, " ")
    roh = Replace(roh, "Apple Pay", " ", , , vbTextCompare)
    roh = Replace(roh, "Google Pay", " ", , , vbTextCompare)
    For Each w In Split(roh, " ")
        s = Trim$(CStr(w))
        u = UCase$(s)
        If s = "" Then GoTo Weiter
        If InStr(" POS ATM O NFC E-COM E-COMM ECOM BEZAHLUNG KARTE KARTENZAHLUNG MC DANKT AT IE DE HR IT NL LU SE ", " " & u & " ") > 0 Then GoTo Weiter
        If u Like "K#" Then GoTo Weiter
        digits = 0
        For i = 1 To Len(s)
            If Mid$(s, i, 1) Like "#" Then digits = digits + 1
        Next i
        If digits > 0 And (digits >= 4 Or InStr(s, ".") > 0 Or InStr(s, ",") > 0 Or InStr(s, ":") > 0 Or InStr(s, "/") > 0 Or digits = Len(s)) Then GoTo Weiter
        out = out & " " & s
Weiter:
    Next w
    out = Trim$(out)
    Do While Len(out) > 1 And InStr(",;.:-/*", Right$(out, 1)) > 0
        out = Trim$(Left$(out, Len(out) - 1))
    Loop
    If out = "" Then out = Trim$(roh)
    If out = UCase$(out) And out <> LCase$(out) Then
        s = ""
        For Each w In Split(out, " ")
            If Len(w) > 3 Then
                s = s & " " & UCase$(Left$(w, 1)) & LCase$(Mid$(w, 2))
            Else
                s = s & " " & w
            End If
        Next w
        out = Trim$(s)
    End If
    SauberName = Left$(out, 40)
End Function
